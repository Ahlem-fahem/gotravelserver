module.exports = (app) => {
    const aides = require('../controllers/aide.controller.js');

    // Create a new Note
    app.post('/aides', aides.create);

    // Retrieve all Notes
    app.get('/aides', aides.findAll);

    // Retrieve a single Note with noteId
    app.get('/aides/:aideId', aides.findOne);

    // Update a Note with noteId
    app.put('/aides/:aideId', aides.update);

    // Delete a Note with noteId
    app.delete('/aides/:aideId', aides.delete);
}