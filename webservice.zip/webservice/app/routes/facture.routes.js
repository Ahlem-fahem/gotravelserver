module.exports = (app) => {
    const facture = require('../controllers/facture.controller');

    app.post('/send',
        facture.send

    );

}