module.exports = (app) => {
    const promotions = require('../controllers/promotion.controller.js');

    // Create a new Note
    app.post('/promotions', promotions.create);

    // Retrieve all Notes
    app.get('/promotions', promotions.findAll);

    // Retrieve a single Note with noteId
    app.get('/promotions/:promotionId', promotions.findOne);

    // Update a Note with noteId
    app.put('/promotions/:promotionId', promotions.update);

    // Delete a Note with noteId
    app.delete('/promotions/:promotionId', promotions.delete);
}