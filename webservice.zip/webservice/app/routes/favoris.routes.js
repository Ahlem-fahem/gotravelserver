module.exports = (app) => {
    const favoriss = require('../controllers/favoris.controller.js');

    // Create a new Note
    app.post('/favoriss', favoriss.create);

    // Retrieve all Notes
    app.get('/favoriss', favoriss.findAll);

    // Retrieve a single Note with noteId
    app.get('/favoriss/:favorisId', favoriss.findOne);

    // Update a Note with noteId
    app.put('/favoriss/:favorisId', favoriss.update);

    // Delete a Note with noteId
    app.delete('/favoriss/:favorisId', favoriss.delete);
}