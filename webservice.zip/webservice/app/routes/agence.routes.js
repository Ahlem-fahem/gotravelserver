module.exports = (app) => {
    const agences = require('../controllers/agence.controller.js');

    // Create a new Note
    app.post('/agences', agences.create);

    // Retrieve all Notes
    app.get('/agences', agences.findAll);

    // Retrieve a single Note with noteId
    app.get('/agences/:agenceId', agences.findOne);

    // Update a Note with noteId
    app.put('/agences/:agenceId', agences.update);

    // Delete a Note with noteId
    app.delete('/agences/:agenceId', agences.delete);
}