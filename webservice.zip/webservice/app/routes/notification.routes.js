module.exports = (app) => {
    const notifications = require('../controllers/notification.controller.js');

    // Create a new Note
    app.post('/notifications', notifications.create);

    // Retrieve all Notes
    app.get('/notifications', notifications.findAll);

    // Retrieve a single Note with noteId
    app.get('/notifications/:notificationId', notifications.findOne);

    // Update a Note with noteId
    app.put('/notifications/:notificationId', notifications.update);

    // Delete a Note with noteId
    app.delete('/notifications/:notificationId', notifications.delete);
}