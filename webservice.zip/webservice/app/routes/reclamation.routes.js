module.exports = (app) => {
    const reclamations = require('../controllers/reclamation.controller.js');

    // Create a new Note
    app.post('/reclamations', reclamations.create);

    // Retrieve all Notes
    app.get('/reclamations', reclamations.findAll);

    // Retrieve a single Note with noteId
    app.get('/reclamations/:reclamationId', reclamations.findOne);

    // Update a Note with noteId
    app.put('/reclamations/:reclamationId', reclamations.update);

    // Delete a Note with noteId
    app.delete('/reclamations/:reclamationId', reclamations.delete);
}