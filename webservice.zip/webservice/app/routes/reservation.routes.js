module.exports = (app) => {
    const reservations = require('../controllers/reservation.controller.js');

    // Create a new Note
    app.post('/reservations', reservations.create);

    // Retrieve all Notes
    app.get('/reservations', reservations.findAll);

    // Retrieve a single Note with noteId
    app.get('/reservations/:reservationId', reservations.findOne);

    // Update a Note with noteId
    app.put('/reservations/:reservationId', reservations.update);

    // Delete a Note with noteId
    app.delete('/reservations/:reservationId', reservations.delete);
}