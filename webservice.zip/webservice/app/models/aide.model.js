const mongoose = require('mongoose');

const AideSchema = mongoose.Schema({
    nomclient: String,
    msg : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Aide', AideSchema);