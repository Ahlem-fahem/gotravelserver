const mongoose = require('mongoose');

const NotificationSchema = mongoose.Schema({
    contenue: String,
    idclient : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Notification', NotificationSchema);