const mongoose = require('mongoose');

const OffreSchema = mongoose.Schema({
    titre: String,
    about : String,
    datedepart : String,
    datefin : String,
    image : String,
    prix : String,
    direction : String,
    planing : String,
    agence : String,
    idagence : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Offre', OffreSchema);