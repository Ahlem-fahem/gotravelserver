const mongoose = require('mongoose');

const FavorisSchema = mongoose.Schema({
    idclient: String,
    idoffre : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Favoris', FavorisSchema);