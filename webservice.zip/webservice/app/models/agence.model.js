const mongoose = require('mongoose');

const AgenceSchema = mongoose.Schema({
    name: String,
    about : String,
    datecreation : String,
    activity : String,
    image : String,
    phone : String,
    adress : String,
    email : String,
    password : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Agence', AgenceSchema);