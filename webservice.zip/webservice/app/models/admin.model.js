const mongoose = require('mongoose');

const AdminSchema = mongoose.Schema({
    username: String,
    email : String,
    password: String,
    phone:String
}, {
    timestamps: true
});

module.exports = mongoose.model('Admin', AdminSchema);