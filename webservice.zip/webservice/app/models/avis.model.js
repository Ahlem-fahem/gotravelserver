const mongoose = require('mongoose');

const AvisSchema = mongoose.Schema({
    idoffre: String,
    idclient : String,
    nomclient : String,
    titre : String,
    content : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Avis', AvisSchema);