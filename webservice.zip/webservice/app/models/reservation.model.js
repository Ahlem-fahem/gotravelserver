const mongoose = require('mongoose');

const ReservationSchema = mongoose.Schema({
    name: String,
    prenonclient : String,
    idclient : String,
    idoffre : String,
    remarque : String,
    nbadulte : String,
    nbenfant : String,
    idagence:String
}, {
    timestamps: true
});

module.exports = mongoose.model('Reservation', ReservationSchema);