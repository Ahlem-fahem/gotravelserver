const mongoose = require('mongoose');

const ReclamationSchema = mongoose.Schema({
    name: String,
    sujet : String,
    msg : String,
    email : String

}, {
    timestamps: true
});

module.exports = mongoose.model('Reclamation', ReclamationSchema);