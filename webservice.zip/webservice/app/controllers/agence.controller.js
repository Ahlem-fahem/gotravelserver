const Agence = require('../models/agence.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.name) {
        return res.status(400).send({
            message: "agence content can not be empty"
        });
    }

    // Create a Note
    const agence = new Agence({
        name: req.body.name,
        about : req.body.about,
        datecreation : req.body.datecreation,
        activity : req.body.activity,
        image : req.body.image,
        phone : req.body.phone,
        adress : req.body.adress,
        email : req.body.email,
        password : req.body.password
    });

    // Save Note in the database
    agence.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the agence."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Agence.find()
    .then(agences => {
        res.send(agences);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving agence."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Agence.findById(req.params.agenceId)
    .then(agence => {
        if(!agence) {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });            
        }
        res.send(agence);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving agence with id " + req.params.agenceId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.name) {
        return res.status(400).send({
            message: "agence content can not be empty"
        });
    }

    // Find note and update it with the request body
    Agence.findByIdAndUpdate(req.params.agenceId, {
        name: req.body.name,
        about : req.body.about,
        datecreation : req.body.datecreation,
        activity : req.body.activity,
        image : req.body.image,
        phone : req.body.phone,
        adress : req.body.adress,
        email : req.body.email,
        password : req.body.password

    }, {new: true})
    .then(agence => {
        if(!agence) {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });
        }
        res.send(agence);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });                
        }
        return res.status(500).send({
            message: "Error updating agence with id " + req.params.agenceId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Agence.findByIdAndRemove(req.params.agenceId)
    .then(agence => {
        if(!agence) {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });
        }
        res.send({message: "agence deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "agence not found with id " + req.params.agenceId
            });                
        }
        return res.status(500).send({
            message: "Could not delete agence with id " + req.params.agenceId
        });
    });
};
