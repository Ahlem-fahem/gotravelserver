const nodemailer = require('nodemailer');
const Category = require('../models/category.model.js');



exports.send = (req, res) => {


    let mailOptions = {
    from: 'pfeahlemsirine@gmail.com', // TODO: email sender
        to: req.body.email, // TODO: email receiver
        subject: 'Facture',
        text:  req.body.mail
};
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user:'pfeahlemsirine@gmail.com',
            pass: 'Sirineahlem'
        }
    });


// Step 3
    transporter.sendMail(mailOptions, (err, data) => {
        if (err) {
            return log('Error occurs');
        }
        return log('Email sent!!!');
    });


};
