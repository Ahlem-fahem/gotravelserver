const Aide = require('../models/aide.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.nomclient) {
        return res.status(400).send({
            message: "aide content can not be empty"
        });
    }

    // Create a Note
    const aide = new Aide({
        nomclient: req.body.nomclient,
        msg : req.body.msg
    });

    // Save Note in the database
    aide.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the aide."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Aide.find()
    .then(aides => {
        res.send(aides);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving aide."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Aide.findById(req.params.aideId)
    .then(aide => {
        if(!aide) {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });            
        }
        res.send(aide);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving aide with id " + req.params.aideId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.nomclient) {
        return res.status(400).send({
            message: "aide content can not be empty"
        });
    }

    // Find note and update it with the request body
    Aide.findByIdAndUpdate(req.params.aideId, {
        nomclient: req.body.nomclient,
        msg : req.body.msg

    }, {new: true})
    .then(aide => {
        if(!aide) {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });
        }
        res.send(aide);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });                
        }
        return res.status(500).send({
            message: "Error updating aide with id " + req.params.aideId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Aide.findByIdAndRemove(req.params.aideId)
    .then(aide => {
        if(!aide) {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });
        }
        res.send({message: "aide deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "aide not found with id " + req.params.aideId
            });                
        }
        return res.status(500).send({
            message: "Could not delete aide with id " + req.params.aideId
        });
    });
};
