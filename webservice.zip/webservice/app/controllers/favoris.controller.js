const Favoris = require('../models/favoris.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request


    // Create a Note
    const favoris = new Favoris({
        idclient: req.body.idclient,
        idoffre : req.body.idoffre
    });

    // Save Note in the database
    favoris.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the favoris."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Favoris.find()
    .then(favoriss => {
        res.send(favoriss);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving favoris."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Favoris.findById(req.params.favorisId)
    .then(favoris => {
        if(!favoris) {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });            
        }
        res.send(favoris);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving favoris with id " + req.params.favorisId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.name) {
        return res.status(400).send({
            message: "favoris content can not be empty"
        });
    }

    // Find note and update it with the request body
    Favoris.findByIdAndUpdate(req.params.favorisId, {
        idclient: req.body.idclient,
        idoffre : req.body.idoffre

    }, {new: true})
    .then(favoris => {
        if(!favoris) {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });
        }
        res.send(favoris);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });                
        }
        return res.status(500).send({
            message: "Error updating agence with id " + req.params.favorisId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Favoris.findByIdAndRemove(req.params.favorisId)
    .then(favoris => {
        if(!favoris) {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });
        }
        res.send({message: "favoris deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "favoris not found with id " + req.params.favorisId
            });                
        }
        return res.status(500).send({
            message: "Could not delete favoris with id " + req.params.favorisId
        });
    });
};
