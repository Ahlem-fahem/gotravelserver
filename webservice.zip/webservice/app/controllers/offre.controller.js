const Offre = require('../models/offre.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.titre) {
        return res.status(400).send({
            message: "offre content can not be empty"
        });
    }

    // Create a Note
    const offre = new Offre({
        titre: req.body.titre,
        about : req.body.about,
        datedepart : req.body.datedepart,
        datefin : req.body.datefin,
        image : req.body.image,
        prix : req.body.prix,
        direction : req.body.direction,
        planing : req.body.planing,
        agence : req.body.agence,
        idagence : req.body.idagence
    });

    // Save Note in the database
    offre.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the offre."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Offre.find()
    .then(offres => {
        res.send(offres);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving offre."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Offre.findById(req.params.offreId)
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });            
        }
        res.send(offre);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving offre with id " + req.params.offreId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.titre) {
        return res.status(400).send({
            message: "offre content can not be empty"
        });
    }

    // Find note and update it with the request body
    Offre.findByIdAndUpdate(req.params.offreId, {
        titre: req.body.titre,
        about : req.body.about,
        datedepart : req.body.datedepart,
        datefin : req.body.datefin,
        image : req.body.image,
        prix : req.body.prix,
        direction : req.body.direction,
        planing : req.body.planing,
        agence : req.body.agence,
        idagence : req.body.idagence

    }, {new: true})
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });
        }
        res.send(offre);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Error updating offre with id " + req.params.offreId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Offre.findByIdAndRemove(req.params.offreId)
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });
        }
        res.send({message: "offre deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Could not delete offre with id " + req.params.offreId
        });
    });
};
